import java.io.*;
import java.lang.String;
public class project0 {

        public static void main(String[] args)
        {
            //Variables
            String fileName ="";
            String fileOutName, newLine, line;
            int comIndex;
            boolean comment= false;
            
			if (args.length == 0)	//no arguments, need a file
			{
				System.out.println("Please pass an input file name");
                fileName = "";
                return;
			}
            else if (args[0].contains(".in")) //check if the filename was the first argument
            {
                fileName = args[0];	//if so, set it
                if (args.length == 2) 	//check if the no-comments flag was passed as a second argument
                {
                    if (args[1].equals("no-comments"))
                    {
                        comment = true;
                    }
                }
            }
            else if (args[1].contains(".in")) {	//check if filename was the second argument
                fileName = args[1];
                //and look for no comments flag in the first spot

                if (args[0].equals("no-comments"))
                {
                    comment = true;
                }
            }
            else
            {
                //in this case, nothing that looks like an input file was passed, bug the user
                System.out.println("Please pass an input file name");
                fileName = "";
                return;
            }
            //break the file name extension off and append .out
            fileOutName = (fileName.split("\\."))[0];
            fileOutName = fileOutName + ".out";

            try {
                //prepare to read and write from/to our input/output files
                FileReader fileIn = new FileReader (fileName);
                BufferedReader reader = new BufferedReader(fileIn);
                FileWriter fileOut = new FileWriter (fileOutName);
                BufferedWriter writer = new BufferedWriter(fileOut);

                while ((line=reader.readLine()) != null)	//read from this file into we hit the end
                {
                    newLine = line.replaceAll("[\t ]",""); //replace spaces and tabs
                    if (newLine.length() != 0) {	//check if a line was blank, can leave it off if so
                        if (comment) {	//check if we're deleting comments
                            comIndex = newLine.indexOf("//");	//find location of comments
                            if (comIndex!=-1)
                            {
                                newLine = newLine.substring(0,comIndex);	//if there is a comment, take the substring of index 0 up the start of the comment exclusive
                            }
                        }
                        fileOut.write(newLine + "\n");
                    }
                }
                fileOut.close();	//close the output stream
            }
            catch(IOException e)
            {
                System.out.println("IOException");	//handle ioexceptions
            }
        }

}
