I'm just compiling with javac on the linux computers. (so "javac project0.java")
Arguments and the no comments flag are passed as directed (so "java test.in no-comments" or "java no-comments test.in")
The output file ends with a newline, but I think that's standard? Everything else seems to work as instructed.


